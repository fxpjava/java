package tanxin;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class zucheqilvdao {

    public static int max_machine = 0;

    // 左右双指针
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int m = scanner.nextInt();
        int n = scanner.nextInt();

        ArrayList<Integer> weights = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            int a = scanner.nextInt();
            weights.add(a);
        }

        Collections.sort(weights);

        int left = 0;
        int right = weights.size()-1;

        int min_bikes = 0;

        int temp_weight = weights.get(right)+weights.get(left);

        while (left<right){
            if(temp_weight>m){
                right--;
                min_bikes += 1;
                temp_weight = weights.get(right) + weights.get(left);
            }else {
                right--;
                left++;
                min_bikes += 1;
                temp_weight = weights.get(right)+ weights.get(left);
            }
        }
        if(left == right){
            min_bikes++;
        }
        System.out.println(min_bikes);

    }


}
