package tanxin;

import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Scanner;

public class tongyixianzaihuowuzuixiaozhi {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();

        int[] goods = new int[n];
        for (int i = 0; i < n; i++) {
            goods[i] = sc.nextInt();
        }

        int[] types = new int[n];
        for (int i = 0; i < n; i++) {
            types[i] = sc.nextInt();
        }

        int k = sc.nextInt();

        System.out.println(getResult(n, goods, types, k));
    }

    public static int getResult(int n, int[] goods, int[] types, int k) {
        PriorityQueue<LinkedList<Integer>> drys = new PriorityQueue<>((a, b) -> b.get(0) - a.get(0));
        PriorityQueue<LinkedList<Integer>> wets = new PriorityQueue<>((a, b) -> b.get(0) - a.get(0));

        boolean isDry = true;
        LinkedList<Integer> tmp = new LinkedList<>();
        int sum = 0;

        for (int i = 0; i < n; i++) {
            if (types[i] == 0) {
                if (isDry) {
                    tmp.add(goods[i]);
                    sum += goods[i];
                } else {
                    tmp.addFirst(sum);
                    wets.offer(tmp);

                    tmp = new LinkedList<>();
                    sum = 0;

                    tmp.add(goods[i]);
                    sum += goods[i];

                    isDry = true;
                }
            } else {
                if (isDry) {
                    tmp.addFirst(sum);
                    drys.offer(tmp);

                    tmp = new LinkedList<>();
                    sum = 0;

                    tmp.add(goods[i]);
                    sum += goods[i];

                    isDry = false;
                } else {
                    tmp.add(goods[i]);
                    sum += goods[i];
                }
            }
        }

        tmp.addFirst(sum);
        if (isDry) {
            drys.offer(tmp);
        } else {
            wets.offer(tmp);
        }

        int dry_min = divide(drys, k);
        int wet_min = divide(wets, k);

        return Math.max(dry_min, wet_min);
    }

    public static int divide(PriorityQueue<LinkedList<Integer>> goods, int k) {
        while (goods.size() < k) {
            LinkedList<Integer> top = goods.poll();

            if (top == null) break;

            int dry_sum = top.removeFirst();

            if (top.size() == 1) {
                return dry_sum;
            }

            int splitIdx = 0;
            int splitHalf = 0;
            int half = 0;
            int min = dry_sum;

            for (int i = 1; i < top.size(); i++) {
                int val = top.get(i - 1);
                half += val;

                int max = Math.max(half, dry_sum - half);
                if (max < min) {
                    min = max;
                    splitIdx = i;
                    splitHalf = half;
                }
            }

            LinkedList<Integer> halfList = new LinkedList<>();
            halfList.add(splitHalf);
            halfList.addAll(top.subList(0, splitIdx));
            goods.offer(halfList);

            LinkedList<Integer> otherHalfList = new LinkedList<>();
            otherHalfList.add(dry_sum - splitHalf);
            otherHalfList.addAll(top.subList(splitIdx, top.size()));
            goods.offer(otherHalfList);
        }

        return goods.peek().get(0);
    }

}
