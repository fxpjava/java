package tanxin;

import java.util.*;

public class zuijiaduishou {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        int d = scanner.nextInt();
        int[] arr = new int[n];
        for (int i = 0; i < n; i++) {
            arr[i] = scanner.nextInt();
        }

        System.out.println(getResult(n,d,arr));

    }

    private static int getResult(int n, int d, int[] arr) {
        Arrays.sort(arr);
        ArrayList<Integer[]> diffs = new ArrayList<>();
        for (int i = 1; i < arr.length; i++) {
            int diff = arr[i] - arr[i-1];
            if(diff<=d){
                diffs.add(new Integer[]{i-1,i,diff});
            }
        }

        if(diffs.size() == 0){
            return -1;
        }
        ArrayList<Integer[]> res = new ArrayList<>();
        dfs(0,diffs,new LinkedList<>(),res);

        res.sort((a,b)-> Objects.equals(a[0],b[0])?a[1]-a[1] : b[0]-a[0]);
        return res.get(0)[1];
    }

    private static void dfs(int index, ArrayList<Integer[]> diffs, LinkedList<Integer[]> path, ArrayList<Integer[]> res) {
        for (int i = index; i < diffs.size(); i++) {
            if(path.size() == 0 || path.getLast()[1] < diffs.get(i)[0]){
                path.add(diffs.get(i));
                dfs(i+1,diffs,path,res);
                int count = path.size();
                Integer sumDiff = path.stream().map(e -> e[2]).reduce((p, c) -> p + c).orElse(0);
                res.add(new Integer[]{count,sumDiff});
                path.removeLast();
            }


        }

    }


}
