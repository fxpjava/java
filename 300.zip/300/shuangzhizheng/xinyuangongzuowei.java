package shuangzhizheng;

import java.util.HashMap;
import java.util.Scanner;

public class xinyuangongzuowei {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String[] arr = sc.nextLine().split(" ");

        System.out.println(getResult(arr));
    }

    public static int getResult(String[] arr) {
        // 记录空位的友好度
        HashMap<Integer, Integer> ep = new HashMap<>();

        int friendShip = 0;
        // 从左向右遍历，记录每个空位左边的友好度
        for (int i = 0; i < arr.length; i++) {
            switch (arr[i]) {
                case "0":
                    ep.put(i, friendShip);
                    friendShip = 0;
                    break;
                case "1":
                    friendShip++;
                    break;
                case "2":
                    friendShip = 0;
                    break;
            }
        }

        friendShip = 0;
        int ans = 0;
        // 从右向左遍历，累加每个空位右边的友好度，这样就得到了每个空位的友好度，取最大值即可
        for (int i = arr.length - 1; i >= 0; i--) {
            switch (arr[i]) {
                case "0":
                    ans = Math.max(ans, ep.get(i) + friendShip);
                    friendShip = 0;
                    break;
                case "1":
                    friendShip++;
                    break;
                case "2":
                    friendShip = 0;
                    break;
            }
        }

        return ans;
    }

}
