package shuangzhizheng;

import java.util.Arrays;
import java.util.Scanner;

public class tianranchushuku {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Integer[] s = Arrays.stream(scanner.nextLine().split(" ")).map(Integer::parseInt).toArray(Integer[]::new);

        System.out.println(getResult(s));


    }

    private static String getResult(Integer[] s) {

        Integer[] ans = new Integer[]{0,0,0};

        int l = 0;
        int r = s.length-1;
        int maxSum = 0;
        while (l<r) {
            int sum = 0;
            int lower = Math.min(s[l], s[r]);

            for (int i = l; i <= r; i++) {
                sum += Math.max(0, lower - s[i]);
            }
            if (sum >= maxSum) {
                ans = new Integer[]{l, r, sum};
                maxSum = sum;
            }
            if (s[l] < s[r]) {
                l++;
            } else if (s[l] > s[r]) {
                r--;
            } else if (s[l + 1] >= s[l]) {
                l++;
            } else {
                r--;
            }
        }

            if(ans[2]==0){
                return "0";
            }



        return ans[0] + " " +ans[1]+":"+ans[2];

    }

}
