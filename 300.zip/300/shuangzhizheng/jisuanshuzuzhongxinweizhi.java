package shuangzhizheng;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.Scanner;

public class jisuanshuzuzhongxinweizhi {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        Integer[] arr = Arrays.stream(scanner.nextLine().split(" ")).map(Integer::parseInt).toArray(Integer[]::new);

        System.out.println(getResult(arr));


    }

    private static int getResult(Integer[] nums) {
        BigInteger fact = BigInteger.valueOf(1);
        for (Integer num:nums) {
            fact = fact.multiply(BigInteger.valueOf(num));
        }
        BigInteger left = BigInteger.valueOf(1);
        BigInteger right = fact.divide(BigInteger.valueOf(nums[0]));

        if(left.compareTo(right) == 0){
            return 0;
        }

        for (int i = 1; i < nums.length; i++) {
            left = left.multiply(BigInteger.valueOf(nums[i-1]));
            right = right.divide(BigInteger.valueOf(nums[i]));
            if(left.compareTo(right)==0){
                return i;
            }

        }
        return -1;
    }


}
