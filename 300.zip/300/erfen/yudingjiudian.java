package erfen;

import java.util.Arrays;
import java.util.Scanner;
import java.util.StringJoiner;

public class yudingjiudian {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        int k = sc.nextInt();
        int x = sc.nextInt();

        int[] prices = new int[n];
        for (int i = 0; i < n; i++) {
            prices[i] = sc.nextInt();
        }

        System.out.println(getResult(n, k, x, prices));
    }

    public static String getResult(int n, int k, int x, int[] prices) {
        // 数组升序
        Arrays.sort(prices);

        // 二分查找数组中最接近心理价位x的元素的位置idx
        int idx = Arrays.binarySearch(prices, x);

        // 如果idx<0，说明在数组中没有找到对应值，因此此时idx是有序插入位置
        if (idx < 0) {
            idx = -idx - 1; // 将idx转换为有序插入位置

            // 如果idx的插入位置越界，则只会是右边界越界
            if (idx == prices.length) {
                int[] ans = Arrays.copyOfRange(prices, idx - k, idx);
                StringJoiner sj = new StringJoiner(" ");
                for (int an : ans) {
                    sj.add(an + "");
                }
                return sj.toString();
            }

            int diff1 = Math.abs(x - prices[idx]);
            int diff2 = Math.abs(x - prices[idx - 1]);
            if (diff1 > diff2) {
                // 选择最接近的值的位置作为中心位置
                idx -= 1;
            }
        }

        // 中心位置的值算1个接近心里价位的值，因此已经找到1个，所以k--
        k--;

        int left = idx;
        int right = idx;
        while (k > 0) {
            int leftVal = left == 0 ? Integer.MAX_VALUE : prices[left - 1];
            int rightVal = right == n - 1 ? Integer.MAX_VALUE : prices[right + 1];

            // 从中心位置向两边发散
            int diff1 = Math.abs(x - leftVal);
            int diff2 = Math.abs(x - rightVal);

            // 那边值更接近，则范围向哪边扩大
            if (diff1 <= diff2) {
                left--;
            } else {
                right++;
            }

            // 每次都能找到一个最接近的心里价位
            k--;
        }

        // left,right范围就是题解
        int[] ans = Arrays.copyOfRange(prices, left, right + 1);
        StringJoiner sj = new StringJoiner(" ");
        for (int an : ans) {
            sj.add(an + "");
        }
        return sj.toString();
    }



}
