package erfen;

import java.util.Arrays;
import java.util.Scanner;

public class rizhixianliu {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        int[] records = new int[n];
        for (int i = 0; i < n; i++) {
            records[i] = scanner.nextInt();
        }
        
        int total = scanner.nextInt();
        System.out.println(getResult(n,records,total));

    }

    private static int getResult(int n, int[] records, int total) {

        int sum = Arrays.stream(records).reduce(Integer::sum).getAsInt();

        if(sum<=total){
            return -1;
        }
        Arrays.sort(records);
        int max_limit = records[records.length-1];
        int min_limit = total/n;

        int ans = max_limit;
        while (max_limit - min_limit>1){
            int limit = (max_limit + min_limit)/2;
            int tmp = 0;
            for (int record:records) {
                tmp += Math.min(record,limit);
            }

            if(tmp>total){
                max_limit = limit;
            }else if (tmp < total){
                min_limit = limit;
                ans = limit;
            }else {
                return limit;
            }
        }
        return ans;
    }


}
