package erfen;

import java.util.ArrayList;
import java.util.Scanner;

public class fuwuzhongxinxuanzhi {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        double[][] positions = new double[n][2];
        for (int i = 0; i < n; i++) {
            positions[i][0] = sc.nextInt();
            positions[i][1] = sc.nextInt();
        }
        System.out.println(getResult(n,positions));

    }

    private static double getResult(int n, double[][] positions) {
        ArrayList<Double> tmp = new ArrayList<>();
        for (double[] pos:positions) {
            tmp.add(pos[0]);
            tmp.add(pos[1]);
        }
        tmp.sort(Double::compareTo);
        
        double min = tmp.get(0);
        double max = tmp.get(tmp.size() -1);
        while (min < max){
            double mid = Math.ceil((min + max) / 2);
            double midDis = getDistance(mid, positions);
            double midLDis = getDistance(mid - 0.5, positions);
            double midRDis = getDistance(mid+0.5, positions);

            if(midDis <= midLDis && midDis <= midRDis){
                return midDis;
            }

            if(midDis < midLDis){
                mid = mid + 0.5;
                continue;
            }
            if(midDis<midRDis){
                max = mid - 0.5;
            }

        }
        return 0;
    }

    private static double getDistance(double t, double[][] positions) {
        double dis = 0;
        for (double[] pos:positions) {
            double l = pos[0];
            double r = pos[1];
            if(r<t){
                dis += t-r;
            } else if(t<l){
                dis += l-t;
            }
        }
        return dis;


    }


}
