package huadongchuangkou;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Scanner;

public class zuiduoyansecheliang {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        Integer[] arr = Arrays.stream(scanner.nextLine().split(" ")).map(Integer::parseInt).toArray(Integer[]::new);
        int n = scanner.nextInt();
        System.out.println(getResult(arr,n));

    }

    private static int getResult(Integer[] arr, int n) {

        HashMap<Integer, Integer> count = new HashMap<>();
        count.put(0,0);
        count.put(1,0);
        count.put(2,0);

        int l = 0;
        int r = l + n;

        int max = 0;
        for (int i = l; i < r; i++) {
            Integer c = arr[i];
            count.put(c,count.get(c)+1);
            max = Math.max(max,count.get(c));
        }

        while (r<arr.length){
            Integer add = arr[r++];
            Integer remove = arr[l++];

            count.put(add,count.get(add)+1);
            count.put(remove,count.get(remove)-1);

            max = Math.max(max,count.get(add));
        }
        return max;

    }


}
