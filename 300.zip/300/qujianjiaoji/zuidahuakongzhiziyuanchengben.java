package qujianjiaoji;

import java.util.Arrays;
import java.util.PriorityQueue;
import java.util.Scanner;

public class zuidahuakongzhiziyuanchengben {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();

        int[][] ranges = new int[n][3];

        for (int i = 0; i < n; i++) {
            ranges[i][0] = sc.nextInt();
            ranges[i][1] = sc.nextInt();
            ranges[i][2] = sc.nextInt();
        }

        System.out.println(getResult(ranges));
    }

    public static int getResult(int[][] ranges) {
        Arrays.sort(ranges, (a, b) -> a[0] - b[0]);

        PriorityQueue<Integer[]> end = new PriorityQueue<>((a, b) -> a[0] - b[0]);

        int max = 0;
        int sum = 0;
        for (int[] range : ranges) {
            int s = range[0];
            int e = range[1];
            int p = range[2];

            while (end.size() > 0) {
                Integer[] top = end.peek();

                if (top[0] < s) {
                    Integer[] poll = end.poll();
                    sum -= poll[1];
                } else {
                    break;
                }
            }

            end.offer(new Integer[] {e, p});
            sum += p;

            if (sum > max) {
                max = sum;
            }
        }
        return max;
    }


}
