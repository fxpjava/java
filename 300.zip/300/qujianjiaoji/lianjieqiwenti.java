package qujianjiaoji;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class lianjieqiwenti {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String f = sc.nextLine();
        Integer[][] ranges =
                Arrays.stream(f.substring(1, f.length() - 1).split("],\\["))
                        .map(
                                str -> Arrays.stream(str.split(",")).map(Integer::parseInt).toArray(Integer[]::new))
                        .toArray(Integer[][]::new);

        String s = sc.nextLine();
        List<Integer> connects =
                Arrays.stream(s.substring(1, s.length() - 1).split(","))
                        .map(Integer::parseInt)
                        .collect(Collectors.toList());

        System.out.println(getResult(ranges, connects));
    }

    public static int getResult(Integer[][] ranges, List<Integer> connects) {
        Arrays.sort(ranges, (a, b) -> a[0] - b[0]);

        LinkedList<Integer[]> mergeRanges = new LinkedList<>();
        mergeRanges.addLast(ranges[0]);

        LinkedList<Integer> diffs = new LinkedList<>();

        for (int i = 1; i < ranges.length; i++) {
            Integer[] last = mergeRanges.getLast();
            int s1 = last[0];
            int e1 = last[1];

            Integer[] range = ranges[i];
            int s2 = range[0];
            int e2 = range[1];

            if (s2 <= e1) {
                mergeRanges.removeLast();
                mergeRanges.addLast(new Integer[] {s1, Math.max(e1, e2)});
            } else {
                diffs.addLast(s2 - e1);
                mergeRanges.addLast(range);
            }
        }

        diffs.sort((a, b) -> b - a);
        connects.sort((a, b) -> b - a);

        while (connects.size() > 0 && diffs.size() > 0) {
            if (connects.remove(connects.size() - 1) >= diffs.getLast()) {
                diffs.removeLast();
            }
        }

        return diffs.size() + 1;
    }


}
