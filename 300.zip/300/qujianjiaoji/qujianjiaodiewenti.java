package qujianjiaoji;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.Scanner;

public class qujianjiaodiewenti {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = Integer.parseInt(sc.nextLine());

        Integer[][] ranges = new Integer[n][];
        for (int i = 0; i < n; i++) {
            ranges[i] =
                    Arrays.stream(sc.nextLine().split(",")).map(Integer::parseInt).toArray(Integer[]::new);
        }

        System.out.println(getResult(ranges));
    }

    public static int getResult(Integer[][] ranges) {
        Arrays.sort(ranges, (a, b) -> a[0] - b[0]);

        LinkedList<Integer[]> stack = new LinkedList<>();
        stack.add(ranges[0]);

        for (int i = 1; i < ranges.length; i++) {
            Integer[] range = ranges[i];

            while (true) {
                if (stack.size() == 0) {
                    stack.add(range);
                    break;
                }

                Integer[] top = stack.getLast();
                int s0 = top[0];
                int e0 = top[1];

                int s1 = range[0];
                int e1 = range[1];

                if (s1 <= s0) {
                    if (e1 <= s0) {
                        break;
                    } else if (e1 < e0) {
                        break;
                    } else {
                        stack.removeLast();
                    }
                } else if (s1 < e0) {
                    if (e1 <= e0) {
                        break;
                    } else {
                        stack.add(new Integer[] {e0, e1});
                        break;
                    }
                } else {
                    stack.add(range);
                    break;
                }
            }
        }

        return stack.size();
    }


}
