package youxianduilie;

import java.util.HashMap;
import java.util.PriorityQueue;
import java.util.Scanner;

public class dayinjiduilie {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = Integer.parseInt(scanner.nextLine());
        String[][] matrix = new String[n][];
        for (int i = 0; i < n; i++) {
            String[] s = scanner.nextLine().split(" ");
            matrix[i] = s;
        }
        getResult(matrix);

    }

    private static void getResult(String[][] matrix) {

        HashMap<String, PriorityQueue<Integer[]>> print = new HashMap<>();

        int x = 1;
        for (String[] task:matrix) {
            String type = task[0];
            String printId = task[1];

            if("IN".equals(type)){
                String priority = task[2];

                Integer[] arr = {x,Integer.parseInt(priority)};

                print.putIfAbsent(printId,new PriorityQueue<>((a,b)->b[1]-a[1]));

                print.get(printId).offer(arr);
                x++;
            }else {
                Integer[] arr = print.get(printId).poll();
                if(arr != null){
                    System.out.println(arr[0]);
                }else {
                    System.out.println("NULL");
                }

            }

        }

    }


}
