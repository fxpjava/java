package binchaji;

import java.util.*;

public class wuxiangturanse {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int m = sc.nextInt();
        int n = sc.nextInt();

        int[][] edges = new int[n][2];
        for (int i = 0; i < n; i++) {
            edges[i][0] = sc.nextInt();
            edges[i][1] = sc.nextInt();
        }

        System.out.println(getResult(edges, m));
    }

    /**
     * @param edges 边，即[v1, v2]
     * @param m 点数量
     * @return
     */
    public static int getResult(int[][] edges, int m) {
        UnionFindSet ufs = new UnionFindSet(m);

        for (int[] edge : edges) {
            ufs.union(edge[0], edge[1]);
        }

        // cates对象每个属性对应一个连通分量
        HashMap<Integer, ArrayList<Integer>> cates = new HashMap<>();
        for (int i = 1; i < ufs.fa.length; i++) {
            int fa = ufs.find(i);
            cates.putIfAbsent(fa, new ArrayList<>());
            cates.get(fa).add(i);
        }

        // count记录总染色方案
        int count = 1;

        // 将边归类到对应的连通分量中，并求解每个连通分量的染色方案
        for (Integer fa : cates.keySet()) {
            // 连通分量中点的个数
            int len = cates.get(fa).size();
            HashSet<Integer> set = new HashSet<>(cates.get(fa));

            int[][] indep_edges =
                    Arrays.stream(edges)
                            .filter(edge -> set.contains(edge[0]) || set.contains(edge[1]))
                            .toArray(int[][]::new);

            // 将每个连通分量的染色方案数统计到count中
            count *= getDyeCount(indep_edges, len);
        }
        return count;
    }

    // 该方法连通图的染色方案数
    public static int getDyeCount(int[][] edges, int m) {
        // connect用于存放每个节点的相邻节点
        HashMap<Integer, HashSet<Integer>> connect = new HashMap<>();

        for (int[] edge : edges) {
            connect.putIfAbsent(edge[0], new HashSet<>());
            connect.get(edge[0]).add(edge[1]);

            connect.putIfAbsent(edge[1], new HashSet<>());
            connect.get(edge[1]).add(edge[0]);
        }

        // 节点从index=1开始，必有count=1个的全黑染色方案
        return dfs(connect, m, 1, 1, new LinkedList<>());
    }

    // 该方法用于求解给定多个节点染红的全组合数
    public static int dfs(
            HashMap<Integer, HashSet<Integer>> connect,
            int m,
            int index,
            int count,
            LinkedList<HashSet<Integer>> path) {
        if (path.size() == m) return count;

        outer:
        for (int i = index; i <= m; i++) {
            // 如果新加入节点i和已有节点j相邻，则说明新加入节点不能染成红色，需要进行剪枝
            for (HashSet<Integer> p : path) {
                if (p.contains(i)) continue outer;
            }

            count++;

            path.addLast(connect.get(i));
            count = dfs(connect, m, i + 1, count, path);
            path.removeLast();
        }

        return count;
    }
}


