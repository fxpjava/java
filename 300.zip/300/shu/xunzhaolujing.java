package shu;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class xunzhaolujing {
    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        List<Integer> nodes = Arrays.stream(in.nextLine().split(" "))
                .map(Integer::parseInt)
                .collect(Collectors.toList());

        int[] ints = new int[nodes.size() + 1];
        int minValue = Integer.MAX_VALUE;
        int minPos = 0;

        for (int i = 1; i < ints.length; i++) {
            ints[i] = nodes.get(i - 1);
            // 找到最小叶子节点对应的索引
            if (i > 1 && ints[i] != -1 && ints[i] < minValue) {
                minValue = ints[i];
                minPos = i;
            }
        }
        //往上遍历
        List<Integer> path = new ArrayList<>();
        while (minPos >= 1) {
            path.add(ints[minPos]);
            minPos /= 2;
        }

        for (int i = path.size() - 1; i >= 0; i--) {
            System.out.print(path.get(i));
            if (i != 0) {
                System.out.print(" ");
            }
        }
    }

}
