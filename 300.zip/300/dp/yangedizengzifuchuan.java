package dp;

import java.util.Scanner;

public class yangedizengzifuchuan {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        String str = scanner.next();
        System.out.println(getResult(str));


    }

    private static int getResult(String str) {
        int n = str.length();
        int A = str.replaceAll("B","").length();

        if(A==0 || A==n){
            return 0;
        }
        int dp = 0;
        if(str.charAt(0) == 'A'){
            dp =1;
        }
        int ans = test(0,dp,A-dp);
        for (int i = 1; i < n; i++) {
            if(str.charAt(i) == 'A'){
                dp += 1;
            }
            ans = Math.min(ans,test(i,dp,A-dp));
        }
        return ans;
    }

    private static int test(int brandIdx, int brand_LM_A, int brand_R_A) {

        return brandIdx + 1 - brand_LM_A + brand_R_A;
    }


}
