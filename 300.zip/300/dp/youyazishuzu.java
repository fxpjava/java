package dp;

import java.util.HashMap;
import java.util.Scanner;

public class youyazishuzu {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        int k = sc.nextInt();

        Integer[] arr = new Integer[n];
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }

        System.out.println(getResult(arr, n, k));
    }

    public static Integer getResult(Integer[] arr, Integer n, Integer k) {
        int ans = 0;

        for (int i = 0; i < n; i++) {
            HashMap<Integer, Integer> count = new HashMap<>();

            for (int j = i; j < n; j++) {
                Integer key = arr[j];
                count.put(key, count.getOrDefault(key, 0) + 1);
                if (count.get(key) >= k) {
                    ans += n - j;
                    break;
                }
            }
        }

        return ans;
    }



}
