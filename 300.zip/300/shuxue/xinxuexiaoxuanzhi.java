package shuxue;

import java.util.Arrays;
import java.util.Scanner;

public class xinxuexiaoxuanzhi {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();

        int[] arr = new int[n];
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }

        System.out.println(getResult(arr));
    }

    public static int getResult(int[] arr) {
        Arrays.sort(arr);

        int len = arr.length;
        if (len % 2 == 0) {
            int mid = len / 2;
            return arr[mid - 1];
        } else {
            return arr[len / 2];
        }
    }

}
