package fenzhidigui;

import java.util.Scanner;

public class duichenmeixue {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        int t = scanner.nextInt();

        long[][] arr = new long[t][2];
        for (int i = 0; i < t; i++) {
            arr[i][0] = scanner.nextLong();
            arr[i][1] = scanner.nextLong();
        }
        getResult(arr);

    }

    private static void getResult(long[][] arr) {
        for (long[] nk:arr) {
            System.out.println(getNK(nk[0],nk[1]+1));
        }
    }

    private static String getNK(long n, long k) {
        if(n==1){
            return "red";
        }
        if(n==2){
            if(k==1){
                return "blue";
            }else {
                return "red";
            }
        }
        int half = 1 << (n-2);
        if(k > half){
            return getNK(n-1,k-half);
        }else {
            return "red".equals(getNK(n-1,k))?"blue":"red";
        }


    }


}
