package DFS;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Scanner;

public class jizhanweihugongchenshi {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();

        int[][] matrix = new int[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                matrix[i][j] = sc.nextInt();
            }
        }

        System.out.println(getResult(matrix, n));
    }

    public static int getResult(int[][] matrix, int n) {
        boolean[] used = new boolean[n];
        LinkedList<Integer> path = new LinkedList<>();
        ArrayList<LinkedList<Integer>> res = new ArrayList<>();

        dfs(n, used, path, res);

        int ans = Integer.MAX_VALUE;

        for (LinkedList<Integer> pa : res) {
            int dis = matrix[0][pa.get(0)];
            for (int i = 0; i < pa.size() - 1; i++) {
                int p = pa.get(i);
                int c = pa.get(i + 1);
                dis += matrix[p][c];
            }
            dis += matrix[pa.getLast()][0];
            ans = Math.min(ans, dis);
        }

        return ans;
    }

    public static void dfs(int n, boolean[] used, LinkedList<Integer> path, ArrayList<LinkedList<Integer>> res) {
        if (path.size() == n - 1) {
            res.add((LinkedList<Integer>)path.clone());
            return;
        }

        for (int i = 1; i < n; i++) {
            if (!used[i]) {
                path.push(i);
                used[i] = true;
                dfs(n, used, path, res);
                used[i] = false;
                path.pop();
            }
        }
    }

}
