package DFS;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class AIchuliqi {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        Integer[] cores = Arrays.stream(scanner.nextLine().split("[\\[\\]\\,\\s]"))
                .filter(str -> !"".equals(str)).map(Integer::parseInt)
                .toArray(Integer[]::new);

        int target = scanner.nextInt();

        ArrayList<Integer> processprs_1 = new ArrayList<>();
        ArrayList<Integer> processprs_2 = new ArrayList<>();

        Arrays.sort(cores,(a,b)->a-b);
        for (Integer core:cores) {
            if(core<4){
                processprs_1.add(core);
            }else {
                processprs_2.add(core);
            }
        }

        ArrayList<ArrayList<Integer>> result = new ArrayList<>();
        int length_1 = processprs_1.size();
        int length_2 = processprs_2.size();
        switch (target){
            case 1:
                if(length_1 == 1 || length_2 == 1){
                    if(length_1 == 1){
                        dfs(processprs_1,0,1,new ArrayList<>(),result);
                    }
                    if(length_2 == 1){
                        dfs(processprs_2,0,1,new ArrayList<>(),result);
                    }
                }else if(length_1 == 3 || length_2 == 3){
                    if(length_1 == 3){
                        dfs(processprs_1,0,1,new ArrayList<>(),result);
                    }
                    if(length_2 == 3){
                        dfs(processprs_2,0,1,new ArrayList<>(),result);
                    }
                }else if(length_1 == 2 || length_2 == 2){
                    if(length_1 == 2){
                        dfs(processprs_1,0,1,new ArrayList<>(),result);
                    }
                    if(length_2 == 2){
                        dfs(processprs_2,0,1,new ArrayList<>(),result);
                    }
                }else if(length_1 == 4 || length_2 == 4){
                    if(length_1 == 4){
                        dfs(processprs_1,0,1,new ArrayList<>(),result);
                    }
                    if(length_2 == 4){
                        dfs(processprs_2,0,1,new ArrayList<>(),result);
                    }
                }
                break;
            case 2:
                if(length_1 == 2 || length_2 == 2){
                    if(length_1 == 2){
                        dfs(processprs_1,0,1,new ArrayList<>(),result);
                    }
                    if(length_2 == 2){
                        dfs(processprs_2,0,1,new ArrayList<>(),result);
                    }
                }else if(length_1 == 4 || length_2 == 4){
                    if(length_1 == 4){
                        dfs(processprs_1,0,1,new ArrayList<>(),result);
                    }
                    if(length_2 == 4){
                        dfs(processprs_2,0,1,new ArrayList<>(),result);
                    }
                }else if(length_1 == 3 || length_2 == 3){
                    if(length_1 == 3){
                        dfs(processprs_1,0,1,new ArrayList<>(),result);
                    }
                    if(length_2 == 3){
                        dfs(processprs_2,0,1,new ArrayList<>(),result);
                    }
                }
                break;
            case 4:
                if(length_1 == 4 || length_2 == 4){
                    if(length_1 == 4){
                        result.add(processprs_1);
                    }
                    if(length_2 == 4){
                        result.add(processprs_2);
                    }
                }
                break;
            case 8:
                if(length_1 == 4 || length_2 == 4){
                    result.add(Stream.concat(processprs_1.stream(),processprs_2.stream()).collect(Collectors.toCollection(ArrayList::new)));

                }
                break;
        }
        System.out.println(result.toString());
    }

    public static void dfs(ArrayList<Integer> cores,int index,int level,ArrayList<Integer> path,ArrayList<ArrayList<Integer>> res){
        if(path.size() == level){
            res.add((ArrayList<Integer>) path.clone());
            return;
        }

        for (int i = index; i < cores.size(); i++) {
            path.add(cores.get(i));

            dfs(cores,i+1,level,path,res);
            path.remove(path.size()-1);

        }


    }


}
