package qianzhuihe;

import java.util.Scanner;

public class tansuodikuaijianli {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        int m = sc.nextInt();
        int c = sc.nextInt();
        int k = sc.nextInt();

        int[][] matrix = new int[n][m];

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                matrix[i][j] = sc.nextInt();
            }
        }

        System.out.println(getResult(matrix, n, m, c, k));
    }

    public static int getResult(int[][] matrix, int n, int m, int c, int k) {
        // 行压缩
        int[][] dps = new int[n][];
        // 遍历每一行进行水平方向区块压缩
        for (int i = 0; i < n; i++) {
            int[] arr = matrix[i];
            // 每c个相邻区块压缩的话，则一行最多压缩为m - c + 1个压缩区块
            int[] dp = new int[m - c + 1];

            // 计算每行第一个压缩区块的发电量作为基准值
            for (int j = 0; j < c; j++) {
                dp[0] += arr[j];
            }

            // 第二个开始的压缩区块的发电量，基于和前面一个压缩区块的差异比较计算出，而不是重新全量计算
            for (int j = 1; j < dp.length; j++) {
                dp[j] = dp[j - 1] - arr[j - 1] + arr[j + c - 1];
            }

            dps[i] = dp;
        }

        // 列压缩
        int[][] newDps = new int[m - c + 1][];
        // 遍历经过行压缩后的地块的每一列，在垂直方向上进行压缩
        for (int i = 0; i < m - c + 1; i++) {
            // 如果c个相邻区块压缩的话，则一列最多压缩为n - c + 1个
            int[] newDp = new int[n - c + 1];

            // 计算每列第一个压缩区块的发电量作为基准值
            for (int j = 0; j < c; j++) {
                newDp[0] += dps[j][i];
            }

            // 第二个开始的压缩区块的发电量，基于和前面一个压缩区块的差异比较计算出，而不是重新全量计算
            for (int j = 1; j < newDp.length; j++) {
                newDp[j] = newDp[j - 1] - dps[j - 1][i] + dps[j + c - 1][i];
            }

            newDps[i] = newDp;
        }

        // 统计压缩区域发电量大于等于k的数量
        int ans = 0;
        for (int i = 0; i < newDps.length; i++) {
            for (int j = 0; j < newDps[i].length; j++) {
                if (newDps[i][j] >= k) {
                    ans++;
                }
            }
        }

        return ans;
    }


}
