package luoji;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Scanner;

public class danxianglianbiaozhongjianjiedian {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        String head = scanner.next();
        int n = scanner.nextInt();
        HashMap<String, String[]> nodes = new HashMap<>();
        for (int i = 0; i < n; i++) {
            String addr = scanner.next();
            String val = scanner.next();
            String nextAddr = scanner.next();
            nodes.put(addr,new String[]{val,nextAddr});
        }
        System.out.println(getResult(head,nodes));
    }

    private static String getResult(String head, HashMap<String, String[]> nodes) {

        LinkedList<String> link = new LinkedList<>();
        String[] node = nodes.get(head);
        while (node != null){
            String val = node[0];
            String next = node[1];
            link.add(val);
            node = nodes.get(next);
        }

        int len = link.size();
        int mid = len/2;
        return link.get(mid);
    }


}
