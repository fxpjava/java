package luoji;

import java.util.*;

public class zhenzhengdemima {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        String[] arr = scanner.nextLine().split(" ");
        System.out.println(getResult(arr));


    }

    private static String getResult(String[] arr) {
        Arrays.sort(arr);

        HashMap<Character, ArrayList<String>> samePre = new HashMap<>();

        for (String s:arr) {
            Character prefix = s.charAt(0);
            samePre.putIfAbsent(prefix,new ArrayList<>());
            samePre.get(prefix).add(s);
        }

        ArrayList<String> ans = new ArrayList<>();

        for (Character prefix:samePre.keySet()) {

            ArrayList<String> list = samePre.get(prefix);
            for (int i = list.size()-1; i >=0 ; i--) {
                String pass = list.get(i);
                if(pass.length()>list.size()){
                    continue;
                }

                HashSet<String> set = new HashSet<>(list);

                int j = pass.length()-1;
                while (j>=1){
                    String substring = pass.substring(0,j);
                    if(set.contains(substring)){
                        j--;
                    }else {
                        break;
                    }
                }

                if(j==0){
                    ans.add(pass);
                    break;
                }
            }
        }
        ans.sort((a,b)->a.length() != b.length()?b.length()-a.length():b.compareTo(a));

        return ans.get(0);
    }


}
