package luoji;

import java.util.Scanner;

public class erjinzhichayishu {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();

        int[] arr = new int[n];
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }

        System.out.println(getResult(arr));
    }

    public static int getResult(int[] arr) {
        // highBit是一个数组，由于题目说给定的A[i]取值小于2^30，因此我们可以定义一个30长度的数组，其元素含义是，比如highBit[i]代表最高位1处于第i位的数的个数
        //    int[] highBit = new int[30];
        int[] highBit = new int[60]; // 经网友反馈，这里长度改为60可得100%通过率

        for (int a : arr) {
            String bin = Integer.toBinaryString(a);
            int len = bin.length(); // 数的二进制形式字符串（无前导0）的长度，就是该数二进制最高位1所处位数

            // 将“0”和“1”区别开来
            if ("0".equals(bin)) {
                highBit[0]++;
            } else {
                highBit[len]++;
            }
        }

        int ans = 0;
        for (int i = 0; i < highBit.length; i++) {
            for (int j = i + 1; j < highBit.length; j++) {
                ans += highBit[i] * highBit[j];
            }
        }

        return ans;
    }


}
