package luoji;

import java.util.*;
import java.util.stream.Collectors;

public class zhenglipukepai {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Integer> nums = Arrays.stream(scanner.nextLine().split(" "))
                .map(Integer::parseInt).collect(Collectors.toList());

        HashMap<Integer, Integer> map = new HashMap<>();
        for (int num:nums) {
            map.put(num,map.getOrDefault(num,0)+1);
        }

        // 先按张数排序，再按点数排序
        ArrayList<Map.Entry<Integer, Integer>> list = new ArrayList<>(map.entrySet());
        list.sort((a,b)->{
            if(b.getValue() == a.getValue()){
                return b.getKey()-a.getKey();
            }
            return b.getValue() - a.getValue();
        });

        // 特殊情况处理
        StringBuffer sb = new StringBuffer();
        ArrayList<Integer> split_cards = new ArrayList<>();
        for (int i = 0; i < list.size(); i++) {
            Map.Entry<Integer, Integer> temp = list.get(i);
            int carNum = temp.getKey();
            int carCount = temp.getValue();
            // 3+3的情况拆分成葫芦
            if(i> 0 && list.get(i-1).getValue() == 3 && carCount == 3){
                split_cards.add(carNum);
                carCount = 2;
                temp.setValue(2);
                // 给拆分的牌也要组合一下
            }else if(carCount == 1 && split_cards.size() != 0){
                for (int j = 0; j < split_cards.size(); j++) {
                    if(split_cards.get(j)>carNum){
                        sb.append(split_cards.get(j)+" ");
                        split_cards.remove(j);
                        j--;
                    }
                }
            }
            for (int j = 0; j < carCount; j++) {
                sb.append(carNum+" ");
            }
        }

        if(split_cards.size() != 0){
            for (int i:split_cards) {
                sb.append(i+" ");
            }
        }
        System.out.println(sb.substring(0,sb.length()-1));

    }


}
