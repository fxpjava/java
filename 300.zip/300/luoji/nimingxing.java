package luoji;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Scanner;

public class nimingxing {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String[] newspaper = sc.nextLine().split(" ");
        String[] anonymousLetter = sc.nextLine().split(" ");

        System.out.println(getResult(newspaper, anonymousLetter));
    }

    public static boolean getResult(String[] newspaper, String[] anonymousLetter) {
        HashMap<String, Integer> count = new HashMap<>();
        for (String str : newspaper) {
            String newStr = strSort(str);
            count.put(newStr, count.getOrDefault(newStr, 0) + 1);
        }

        boolean flag = true;
        for (String str : anonymousLetter) {
            String newStr = strSort(str);

            if (count.containsKey(newStr) && count.get(newStr) > 0) {
                count.put(newStr, count.get(newStr) - 1);
            } else {
                flag = false;
                break;
            }
        }

        return flag;
    }

    public static String strSort(String str) {
        char[] cArr = str.toCharArray();
        Arrays.sort(cArr);
        return new String(cArr);
    }

}
