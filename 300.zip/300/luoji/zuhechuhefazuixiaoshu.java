package luoji;

import java.util.Arrays;
import java.util.Scanner;

public class zuhechuhefazuixiaoshu {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        String[] strs = scanner.nextLine().split(" ");
        System.out.println(getResult(strs));


    }

    private static String getResult(String[] strs) {
        Arrays.sort(strs,(a,b)->(a+b).compareTo(b+a));
        if(strs[0].charAt(0)=='0'){
            for (int i = 1; i < strs.length; i++) {
                if(strs[i].charAt(0) !='0'){
                    strs[0] = strs[i]+strs[0];
                    strs[i] = "";
                    break;
                }
            }
        }
        StringBuilder sb = new StringBuilder();
        for (String str:strs) {
            sb.append(str);
        }

        return sb.toString().replaceAll("^0+","");

    }


}
