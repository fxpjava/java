package luoji;

import java.util.Arrays;
import java.util.PriorityQueue;
import java.util.Scanner;

public class gongdandiaoducelue {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();

        int[][] wos = new int[n][2];
        for (int i = 0; i < n; i++) {
            wos[i][0] = sc.nextInt();
            wos[i][1] = sc.nextInt();
        }

        System.out.println(getResult(n, wos));
    }

    /**
     * @param n 工单数量
     * @param wos 工单的 [SLA, 积分]
     * @return 可以获得的最大积分
     */
    public static int getResult(int n, int[][] wos) {
        Arrays.sort(wos, (a, b) -> a[0] - b[0]);
        PriorityQueue<Integer> pq = new PriorityQueue<>((a, b) -> a - b);

        int curTime = 0;
        int ans = 0;
        for (int[] wo : wos) {
            int endTime = wo[0];
            int score = wo[1];

            if (endTime >= curTime + 1) {
                pq.offer(score);
                ans += score;
                curTime++;
            } else {
                if (pq.size() == 0) {
                    continue;
                }

                int min_score = pq.peek();
                if (score > min_score) {
                    pq.poll();
                    pq.offer(score);
                    ans += score - min_score;
                }
            }
        }

        return ans;
    }

}
