package luoji;

import java.util.HashMap;
import java.util.Scanner;

public class tiaoxuanzifuchuan {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String a = sc.next();
        String b = sc.next();

        System.out.println(getResult(a, b));
    }

    public static int getResult(String a, String b) {
        // idxs对象记录字符串b中每个字符的索引
        HashMap<Character, Integer> idxs = new HashMap<>();
        for (int i = 0; i < b.length(); i++) {
            Character c = b.charAt(i);
            idxs.put(c, i); // B不会存在重复字母
        }

        // count对象用于记录遍历字符串a每个字符串过程中，统计到的符合顺序要求的字符串b中字符出现次数
        int[] count = new int[b.length()];
        for (int i = 0; i < a.length(); i++) {
            Character c = a.charAt(i);

            if (idxs.containsKey(c)) {
                int idx = idxs.get(c);
                // 下面判断逻辑请看图解
                if (idx == 0 || count[idx] < count[idx - 1]) {
                    count[idx]++;
                }
            }
        }

        return count[count.length - 1];
    }

}
