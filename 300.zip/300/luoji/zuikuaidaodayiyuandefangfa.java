package luoji;

import java.util.Scanner;

public class zuikuaidaodayiyuandefangfa {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double x = scanner.nextDouble();
        double y = scanner.nextDouble();
        double m = scanner.nextDouble();
        double l = scanner.nextDouble();
        double n = scanner.nextDouble();

        System.out.println(getResult(x,y,m,l,n));
    }

    private static String getResult(double x, double y, double m, double l, double n) {
        double taxiToA = x * 1000 / m + l;
        double walkToB = y * 1000 / n;

        if(taxiToA == walkToB){
            return "Same";
        }else if(taxiToA > walkToB){
            return "Walk";
        }else {
            return "Taxi";
        }


    }


}
