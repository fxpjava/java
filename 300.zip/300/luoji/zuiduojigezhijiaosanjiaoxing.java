package luoji;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Scanner;

public class zuiduojigezhijiaosanjiaoxing {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        int t = scanner.nextInt();
        int[][] cases = new int[t][];
        for (int i = 0; i < t; i++) {
            int n = scanner.nextInt();
            int[] arr = new int[n];
            for (int j = 0; j < n; j++) {
                arr[j] = scanner.nextInt();
            }
            cases[i] = arr;
        }
        getResult(cases);

    }

    private static void getResult(int[][] cases) {
        for (int[] arr:cases) {
            // 对每组测试线段升序排序
            Arrays.sort(arr);

            ArrayList<Integer[]> res = new ArrayList<>();
            dfs(arr,0,new LinkedList<>(),res);
            int[] count = new int[100];
            for (int i:arr) {
                count[i]++;
            }
            ArrayList<Integer> ans = new ArrayList<>();
            canCombine(res,0,count,0,ans);
            System.out.println(ans.stream().max((a,b)->a-b).orElse(0));
        }


    }

    private static void dfs(int[] arr, int index, LinkedList<Integer> path, ArrayList<Integer[]> res) {
        if(path.size() == 3){
            if(isRightTriangle(path)){
                res.add(path.toArray(new Integer[3]));
            }
            return;
        }
        for (int i = index; i < arr.length; i++) {
            path.add(arr[i]);
            dfs(arr,i,path,res);
            path.removeLast();
        }

    }

    private static boolean isRightTriangle(LinkedList<Integer> path) {

        int x = path.get(0);
        int y = path.get(1);
        int z = path.get(2);
        return x*x + y*y == z*z;

    }

    public static void canCombine(ArrayList<Integer[]> ts,int index,int[] count,int num,ArrayList<Integer> ans){
        if(index >= ts.size()){
            ans.add(num);
            return;
        }
        for (int i = index; i < ts.size(); i++) {
            Integer[] tri = ts.get(i);
            int a = tri[0];
            int b = tri[1];
            int c = tri[2];

            if(count[a] > 0 && count[b] > 0 && count[c]>0){
                count[a]--;
                count[b]--;
                count[c]--;
                num++;
                canCombine(ts,i+1,count,num,ans);
                num--;
                count[a]++;
                count[b]++;
                count[c]++;
            }
        }
        ans.add(num);
    }

}
