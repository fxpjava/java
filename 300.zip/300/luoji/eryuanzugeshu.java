package luoji;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;

public class eryuanzugeshu {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        int m = scanner.nextInt();

        ArrayList<Integer> listM = new ArrayList<>();

        for (int i = 0; i < m; i++) {
            listM.add(scanner.nextInt());
        }

        int n = scanner.nextInt();
        ArrayList<Integer> listN = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            listN.add(scanner.nextInt());
        }
        System.out.println(getRssult(listM,listN));
    }

    private static int getRssult(ArrayList<Integer> listM, ArrayList<Integer> listN) {
        HashSet<Integer> setM = new HashSet<>(listM);
        HashSet<Integer> setN = new HashSet<>(listN);

        HashMap<Integer, Integer> countM = new HashMap<>();
        for (Integer m:listM) {
            if(setN.contains(m)){
                countM.put(m,countM.getOrDefault(m,0)+1);
            }
        }

        HashMap<Integer, Integer> countN = new HashMap<>();
        for (Integer n:listN) {
            if(setM.contains(n)){
                countN.put(n,countN.getOrDefault(n,0)+1);
            }
        }

        int count = 0;
        for (Integer k:countM.keySet()) {
            count += countM.get(k) * countN.get(k);
        }
        return count;
    }

}
