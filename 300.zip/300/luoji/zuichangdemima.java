package luoji;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Scanner;

public class zuichangdemima {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String[] arr = sc.nextLine().split(" ");
        System.out.println(getResult(arr));
    }

    public static String getResult(String[] arr) {
        Arrays.sort(arr);

        LinkedList<String> link = new LinkedList<>(Arrays.asList(arr));
        HashSet<String> set = new HashSet<>(link);

        while (link.size() > 0) {
            String str = link.removeLast();
            int end = str.length() - 1;

            while (set.contains(str.substring(0, end))) {
                if (end == 1) {
                    return str;
                } else {
                    end--;
                }
            }
        }

        return "";
    }

}
