package luoji;

import java.util.Arrays;
import java.util.Scanner;

public class mishitaosheng {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String key = sc.nextLine();

        // 注意：用例的第二行输入有问题，这里假设第二行输入为：["s", "sdf134 A2c4b"]
        // 需要注意的是，sc.nextLine()会对输入中的空格做处理，导致我们用正则\\s无法匹配到空格，因此需要给sc.nextLine() + ""
        String str = sc.nextLine() + "";
        String[] boxes = str.substring(2, str.length() - 2).split("\",\\s?\"");

        System.out.println(getResult(key, boxes));
    }

    public static int getResult(String key, String[] boxes) {
        key = strSort(key);

        for (int i = 0; i < boxes.length; i++) {
            String box = boxes[i];
            if (box.length() < key.length()) continue;
            box = strSort(box.toLowerCase());

            int j = 0;
            int k = 0;
            while (k < key.length() && j < box.length()) {
                if (box.charAt(j) == key.charAt(k)) k++;
                j++;
            }

            if (k == key.length()) {
                return i + 1;
            }
        }
        return -1;
    }

    public static String strSort(String str) {
        char[] cArr = str.toCharArray();
        Arrays.sort(cArr);
        return new String(cArr);
    }

}
