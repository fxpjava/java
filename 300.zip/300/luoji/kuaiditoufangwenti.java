package luoji;

import java.util.*;

public class kuaiditoufangwenti {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Integer[] tmp = Arrays.stream(scanner.nextLine().split(" ")).map(Integer::parseInt).toArray(Integer[]::new);

        int m = tmp[0];
        int n = tmp[1];

        String[][] want = new String[m][];
        for (int i = 0; i < m; i++) {
            want[i] = scanner.nextLine().split(" ");
        }

        String[][] cant = new String[n][];
        for (int i = 0; i < n; i++) {
            cant[i] = scanner.nextLine().split(" ");
        }
        System.out.println(getResult(want,cant));


    }

    private static String getResult(String[][] want, String[][] cant) {

        HashMap<String, HashSet<String>> wantMap = new HashMap<>();
        HashMap<String, HashSet<String>> cantMap = new HashMap<>();

        for (String[] arr:want) {
            String pkg = arr[0];
            String path = arr[1] +"-"+arr[2];
            wantMap.putIfAbsent(path,new HashSet<>());
            wantMap.get(path).add(pkg);
        }
        for (String[] arr:cant) {
            String path = arr[0]+"-"+arr[1];
            String[] pkgs = Arrays.copyOfRange(arr, 2, arr.length);
            cantMap.putIfAbsent(path,new HashSet<>());
            cantMap.get(path).addAll(Arrays.asList(pkgs));
        }

        ArrayList<String> ans = new ArrayList<>();

        for (String path:wantMap.keySet()) {
            HashSet<String> wantPKG = wantMap.get(path);
            HashSet<String> cantPKG = cantMap.get(path);
            if(cantPKG == null){
                continue;
            }
            for (String pkg:wantPKG) {
                if(cantPKG.contains(pkg)){
                    ans.add(pkg);
                }
            }
        }

        if(ans.size()==0){
            return "none";
        }
        ans.sort((a,b)->Integer.parseInt(a.substring(7))-Integer.parseInt(b.substring(7)));

        StringJoiner sj = new StringJoiner(" ");
        for (String an:ans) {
            sj.add(an);
        }
        return sj.toString();
    }


}
