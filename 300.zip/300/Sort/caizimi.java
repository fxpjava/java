package Sort;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;
import java.util.StringJoiner;

public class caizimi {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        String[] issues = scanner.nextLine().split(",");
        String[] answers = scanner.nextLine().split(",");
        System.out.println(getResult(issues,answers));

    }

    private static String getResult(String[] issues, String[] answers) {

        ArrayList<String> ans = new ArrayList<>();
        for (String issue:issues) {
            String str1 = getSortedAndDistinctStr(issue);
            boolean find = false;

            for (String answer:answers) {
                String str2 = getSortedAndDistinctStr(answer);
                if(str1.equals(str2)){
                    ans.add(answer);
                    find = true;
                }
            }
            if(!find){
                ans.add("not found");
            }
        }
        StringJoiner sj = new StringJoiner(",", "", "");
        for (String an:ans) {
            sj.add(an);
        }
        return sj.toString();
    }

    private static String getSortedAndDistinctStr(String str) {

        HashSet<Character> set = new HashSet<>();
        for (char c:str.toCharArray()) {
            set.add(c);
        }
        return set.toString();
    }


}
