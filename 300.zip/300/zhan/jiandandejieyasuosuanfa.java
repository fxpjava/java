package zhan;

import java.util.LinkedList;
import java.util.Scanner;

public class jiandandejieyasuosuanfa {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String str = sc.next();
        System.out.println(getResult(str));
    }

    public static String getResult(String str) {
        LinkedList<String> stack = new LinkedList<>();
        // idxs记录 { 出现的索引位置
        LinkedList<Integer> idxs = new LinkedList<>();
        StringBuilder repeat = new StringBuilder();
        str += " ";

        for (int i = 0; i < str.length(); i++) {
            char c = str.charAt(i);
            if (c >= '0' && c <= '9') { // 如果压栈遇到数字
                // 如果出现A13,或者{ABC}99这种情况，我们需要把多位数解析出来
                repeat.append(c);
                continue;
            }

            if (repeat.length() > 0) {
                int n = Integer.parseInt(repeat.toString());
                repeat = new StringBuilder();
                if ("}".equals(stack.getLast())) { // 如果此时栈顶是 } , 则需要将{,} 中间的内容整体重复repeat次
                    int left = idxs.removeLast();
                    stack.remove(left); // 去掉 {
                    stack.removeLast(); // 去掉 }
                    updateStack(stack, left, n); // 将 {,} 中间部分重复 repeat次后重新压栈
                } else { // 如果此时栈顶不是 }，则只需要将栈顶元素重复repeat次即可。
                    updateStack(stack, stack.size() - 1, n);
                }
            }

            // 记录 { 出现的索引位置
            if (c == '{') {
                idxs.addLast(stack.size());
            }

            // 数字外的字符都压入栈中，其中{,}需要再重复操作时删除
            stack.addLast(c + "");
        }

        StringBuilder sb = new StringBuilder();
        for (String c : stack) {
            sb.append(c);
        }
        return sb.toString().trim();
    }

    // 将stack，从left索引开始到最后的内容，弹栈，并整体重复repeat次后，再重新压入栈
    public static void updateStack(LinkedList<String> stack, int left, int repeat) {
        int count = stack.size() - left;

        // frag用于存储弹栈数据
        String[] frag = new String[count];

        while (count-- > 0) {
            frag[count] = stack.removeLast();
        }

        // 由于重复的是弹栈内容的整体，而不是每个，因此需要将弹栈内容合并
        StringBuilder sb = new StringBuilder();
        for (String s : frag) {
            sb.append(s);
        }

        // 将弹栈内容合并后重复repeat次，再重新压入栈中
        String fragment = sb.toString();
        StringBuilder ans = new StringBuilder();

        for (int i = 0; i < repeat; i++) {
            ans.append(fragment);
        }

        stack.addLast(ans.toString());
    }


}
