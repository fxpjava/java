package zhan;

import java.util.LinkedList;
import java.util.Scanner;
import java.util.StringJoiner;

public class xinhaofasheyujieshou {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int m = sc.nextInt();
        int n = sc.nextInt();

        int[][] anth = new int[m][n];

        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                anth[i][j] = sc.nextInt();
            }
        }

        System.out.println(getResult(anth, m, n));
    }

    public static String getResult(int[][] anth, int m, int n) {
        int[][] ret = new int[m][n];

        // 先处理南向发射信号
        for (int j = 0; j < n; j++) {
            LinkedList<Integer> stack = new LinkedList<>();
            for (int i = 0; i < m; i++) {
                common(stack, anth, ret, i, j);
            }
        }

        StringJoiner sj = new StringJoiner(" ");

        // 再处理东向发射信号,和上面同理
        for (int i = 0; i < m; i++) {
            LinkedList<Integer> stack = new LinkedList<>();
            for (int j = 0; j < n; j++) {
                common(stack, anth, ret, i, j);
                sj.add(ret[i][j] + "");
            }
        }

        return m + " " + n + "\n" + sj.toString();
    }

    public static void common(LinkedList<Integer> stack, int[][] anth, int[][] ret, int i, int j) {
        // 如果栈顶天线比anth[i][j]，则anth[i][j]必然能接收到栈顶天线的信号，并且还能继续接收栈顶前面一个天线的信号（递减栈，栈顶前面天线高度必然大于栈顶天线高度）
        while (stack.size() > 0 && anth[i][j] > stack.getLast()) {
            ret[i][j] += 1;
            stack.removeLast();
        }

        // 走到此步，如果stack还有值，那么由于是递减栈，因此此时栈顶天线高度必然
        if (stack.size() > 0) {
            // 如果栈顶天线高度 == anth[i][j]，那么此时anth[i][j]可以接收栈顶天线的信号，
            // 比如5 3 2 3，最后一个3可以接收到前面等高3的信号，但是无法继续接收前面5的信号，因此这里anth[i][j]结束处理
            if (anth[i][j] == stack.getLast()) {
                ret[i][j] += 1;
                stack.removeLast(); // 维护严格递减栈
            }
            // 此情况必然是：anth[i][j] < stack.at(-1)，那么此时anth[i][j]可以接收栈顶天线的信号，
            // 比如6 5 2 3，最后一个3可以接收到前面5的信号，但是无法继续接收更前面6的信号，因此这里anth[i][j]结束处理
            else {
                ret[i][j] += 1;
            }
        }

        stack.add(anth[i][j]);
    }


}
