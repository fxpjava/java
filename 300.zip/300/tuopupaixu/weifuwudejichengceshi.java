package tuopupaixu;

import java.util.*;

public class weifuwudejichengceshi {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();

        int[][] matrix = new int[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                matrix[i][j] = sc.nextInt();
            }
        }

        int k = sc.nextInt();

        System.out.println(getResult(matrix, n, k));
    }

    public static int getResult(int[][] matrix, int n, int k) {
        // next用于保存每个点的后继点
        HashMap<Integer, LinkedList<Integer>> next = new HashMap<>();
        // pre用于保存每个点的前驱点
        HashMap<Integer, LinkedList<Integer>> pre = new HashMap<>();
        // inDegree用于统计每个点的入度
        int[] inDegree = new int[n];

        // 开始统计
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (i == j) continue;
                next.putIfAbsent(j, new LinkedList<>());
                pre.putIfAbsent(i, new LinkedList<>());

                // useTime[i][j] = 1表示服务i启动依赖服务j启动完成，即j的后继点是i；i的前驱点是j
                if (matrix[i][j] == 1) {
                    next.get(j).add(i);
                    inDegree[i]++;
                    pre.get(i).add(j);
                }
            }
        }

        // preK用于记录k点的所有前驱点，包括直接前驱和间接前驱
        HashSet<Integer> preK = new HashSet<>();
        LinkedList<Integer> tmp = pre.get(k - 1);
        while (tmp.size() > 0) {
            int s = tmp.removeFirst();
            preK.add(s);
            tmp.addAll(pre.get(s));
        }

        // 可以同时启动的服务，即同时入度为0的服务，我们需要将这些同时刻入度为0的服务统计在一起，方便统计出最大时间作为这一层服务启动的最终时间
        ArrayList<Integer> zeroDegree = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            // 同时，我们只添加是k服务前驱的入度为0的服务
            if (inDegree[i] == 0 && preK.contains(i)) zeroDegree.add(i);
        }

        // queue用于控制服务的启动
        LinkedList<ArrayList<Integer>> queue = new LinkedList<>();
        if (zeroDegree.size() > 0) queue.add(zeroDegree);

        // ans记录题解，ans必然包含自身启动时间
        int ans = matrix[k - 1][k - 1];

        while (queue.size() > 0) {
            // 当前入度为0的点的集合
            ArrayList<Integer> zd_cur = queue.removeFirst();
            // 下一轮入度为0的点的集合
            ArrayList<Integer> zd_next = new ArrayList<>();

            // zd_cur这些服务中耗时最长的将作为本轮服务启动最终时间
            int max = 0;
            for (int i : zd_cur) {
                max = Math.max(max, matrix[i][i]);
                for (int j : next.get(i)) {
                    // 下一轮同样只统计，k的前驱服务，且入度为0的服务
                    if (--inDegree[j] == 0 && preK.contains(j)) {
                        zd_next.add(j);
                    }
                }
            }

            // 计入本轮服务启动耗时
            ans += max;
            if (zd_next.size() > 0) queue.add(zd_next);
        }

        return ans;
    }


}
