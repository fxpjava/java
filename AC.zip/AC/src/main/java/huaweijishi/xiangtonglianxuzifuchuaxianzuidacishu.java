package huaweijishi;

import java.util.Scanner;

/**
 * 相同字符连续出现的最大次数
 * 题目描述
 * 输入一串字符串
 * 字符串长度不超过100
 * 查找字符串中相同字符连续出现的最大次数
 *
 * 输入描述
 * 输入只有一行，包含一个长度不超过100的字符串
 *
 * 输出描述
 * 输出只有一行，输出相同字符串连续出现的最大次数
 *
 * 示例一
 * 输入
 * hello
 * 1
 * 输出
 * 2
 * 1
 * 示例二
 * 输入
 * word
 * 1
 * 输出
 * 1
 * 1
 * 示例三
 * 输入
 * aaabbc
 * 1
 * 输出
 * 3
 * 1
 *
 */
public class xiangtonglianxuzifuchuaxianzuidacishu {

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            String line = scanner.nextLine();
            solution(line);
        }
    }

    private static void solution(String line) {
        char[] chars = line.toCharArray();
        int maxLen = 0;
        for (int i = 0; i < chars.length; i++) {
            int index = i;
            int len = 1;
            while (index + 1 < chars.length && chars[index + 1] == chars[index]) {
                len++;
                index++;
            }
            if (len > maxLen) maxLen = len;
        }
        System.out.print(maxLen);
    }

}
