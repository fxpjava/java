package huaweijishi;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

/**
 * 滑动窗口
 * 题目描述
 * 有一个N个整数的数组，和一个长度为M的窗口。
 * 窗口从数组内的第一个数开始滑动，直到窗口不能滑动为止。
 * 每次滑动产生一个窗口，和窗口内所有数的和，
 * 求窗口滑动产生的所有窗口和的最大值
 *
 * 输入描述
 * 第一行输入一个正整数N，表示整数个数0 < N < 100000
 *
 * 第二行输入N个整数，整数取值范围[-100,100]
 *
 * 第三行输入正整数M，M代表窗口的大小，M <= N <= 100000
 *
 * 输出描述
 * 窗口滑动产生所有窗口和的最大值
 *
 * 示例一
 * 输入
 * 6
 * 12 10 20 30 15 23
 * 3
 * 1
 * 2
 * 3
 * 输出
 * 68
 *
 */
public class huadongchuangkou {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            int n = Integer.parseInt(scanner.nextLine());
            String[] numsStr = scanner.nextLine().split(" ");
            int m = Integer.parseInt(scanner.nextLine());
            int res = solution(n, numsStr, m);
            System.out.println(res);
        }
    }

    private static int solution(int n, String[] numsStr, int m) {
        List<Integer> integers = new LinkedList<>();
        Arrays.stream(numsStr)
                .forEach(str -> integers.add(Integer.parseInt(str)));

        int res = Integer.MIN_VALUE;
        for (int i = 0; i < n - m + 1; i++) {
            int sum = 0;
            for (int j = i; j < i + m; j++) {
                sum += integers.get(j);
            }
            if (sum > res) res = sum;
        }

        return res;
    }

}
