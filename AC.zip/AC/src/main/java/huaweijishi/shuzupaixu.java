package huaweijishi;

import java.util.*;

/**
 * 数组排序
 * 题目描述
 * 给定一个乱序的数组
 * 删除所有重复元素
 * 使得每个元素只出现一次
 * 并且按照出现的次数从高到低进行排序
 * 相同出现次数按照第一次出现顺序进行先后排序
 * 数组大小不超过100
 * 数组元素值不超过100
 *
 * 输入描述
 * 一个数组
 *
 * 输出描述
 * 去重排序后的数组
 *
 * 示例一
 * 输入
 * 1,3,3,3,2,4,4,4,5
 * 1
 * 输出
 * 3,4,1,2,5
 * 1
 */
public class shuzupaixu {

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            String line = scanner.nextLine();
            solution(line);
        }
    }


    private static void solution(String line) {
        String[] split = line.split(",");
        List<Integer> list = new ArrayList<>();
        Map<Integer, Integer> map = new HashMap<>();
        for (String str : split) {
            int num = Integer.parseInt(str);
            if (!list.contains(num)) {
                list.add(num);
            }
            map.put(num, map.getOrDefault(num, 0) + 1);
        }
        List<int[]> res = new ArrayList<>();
        for (Integer i : list) {
            int[] ints = new int[2];
            ints[0] = i;
            ints[1] = map.get(i);
            res.add(ints);
        }

        res.sort((a1, a2) -> Integer.compare(a2[1], a1[1]));

        for (int i = 0; i < res.size(); i++) {
            System.out.print(res.get(i)[0]);
            if (i != res.size() - 1) {
                System.out.print(",");
            }
        }

    }
}
