package DesignPatterns.singleton.test;

/**
 * Created by Tom.
 */
public class Pojo {
}
