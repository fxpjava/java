package DesignPatterns.prototype.simple;

/**
 * Created by Tom.
 */
public class ConcretePrototypeB implements Prototype {

    @Override
    public Prototype clone() {
        return null;
    }
}
