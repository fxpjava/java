package DesignPatterns.prototype.simple;

/**
 * Created by Tom.
 */
public interface Prototype{
    Prototype clone();
}
