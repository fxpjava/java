package DesignPatterns.adapter.poweradapter;

/**
 * Created by Tom on 2019/3/16.
 */
public interface DC5 {
    int outoupDC5V();
}
