package erchashufenzhi;

import javax.swing.tree.TreeNode;

public class divideConquer {

//    public ResultType divideConquer(TreeNode node){
//
//        // 递归出口
//
//        // 一般处理node==null就够了
//
//        // 大部分情况不需要处理node == leaf
//
//        if(node == null){
//            return ...;
//        }
//
//        // 处理左子树
//        ResultType leftResult = divideConquer(node.left);
//
//        // 处理右子树
//        ResultType rightResult = divideConquer(node.right);
//
//        // 合并答案
//        ResultType result = merge leftResult and rightResult;
//
//        return result;

//    }


}
