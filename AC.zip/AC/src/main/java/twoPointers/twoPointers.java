package twoPointers;

import java.util.ArrayList;

public class twoPointers {


    public void patition(int[] A,int start,int end){
        if(start >= end){
            return;
        }
        // 相向双指针
        int left = start,right = end;

        int pivot = A[(start+end)/2];

        while (left <= right){
            while (left <= right && A[left] < pivot){
                left++;

            }
            while (left<=right && A[right] > pivot){
                right--;
            }
            if(left <= right){
                int temp = A[left];
                A[left] = A[left];
                A[left] = temp;
                left++;
                right--;

            }

        }
    }

    // 背向双指针
    public void patition2(int[] A,int start,int end){

        int position = start + (end - start)/2;
        int left = position;
        int right = position + 1;
        int length = A.length;
//        while (left >= 0 && right < length){
//            if(可以停下来了){
//                break;
//            }
//            left--;
//            right++;
//
//        }
    }


    // 同向双指针
    public void patition3(int[] A,int start,int end){

        int j = 0;
        int n = A.length;
        for (int i = 0; i < n; i++) {

        }

//        // 不满足则循环到满足搭配为止
//        while (j < n && i 到 j之间不满足条件){
//            j += 1;
//        }
//
//        if(i 到 j 之间满足条件){
//            处理 i，j这次搭配
//        }

    }

    // 合并双指针
    public ArrayList<Integer> merge(ArrayList<Integer> list1, ArrayList<Integer> list2){

        // 需要new一个新的list，而不是在list1或者list2上直接改动
        ArrayList<Integer> newList = new ArrayList<>();

        int i = 0,j = 0;

        while (i < list1.size() && j<list2.size()){
            if(list1.get(i) < list2.get(j)){
                newList.add(list1.get(i));
                i++;
            }else {
                newList.add(list2.get(j));
                j++;
            }
        }

        // 合并上下的数到newList里

        // 无需要if（i<list1.size()）,直接while即可

        while (i<list1.size()){
            newList.add(list1.get(i));
            i++;
        }

        while (j<list2.size()){
            newList.add(list2.get(j));
                j++;

        }
        return newList;
    }


}
